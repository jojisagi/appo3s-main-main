class BackendLauncher {
  static Future<void> launchIfNeeded() async {}
}