/// Versión “vacía” para Flutter Web.
/// Simplemente cumple la misma API sin hacer nada.
class ServerLauncher {
  static Future<void> launchIfNeeded() async {}
}
